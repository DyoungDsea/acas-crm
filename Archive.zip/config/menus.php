<?php

// Sidebar menu trees. One file so both roles' navigation is visible
// at a glance and easy to reorder — the recursive sidebar-menu
// component renders whatever depth of "children" it finds, so a
// third or fourth level just works without touching the component.
//
// 'route' => null means "not built yet" — the component links these
// to '#' and fires a "coming soon" notice on click (see app.js)
// rather than a dead link with no feedback.
//
// 'types' => [...] restricts an item to specific company `type`
// values (see the Company model's themeKey()/type column) — used on
// the "Operations" branch below so a pharmacy doesn't see "Vehicles
// & bookings" and a farm doesn't see "Pharmacy stock". Items with no
// 'types' key are shown to every company.
//
// 'adminOnly' => true hides an item from plain staff — used on
// "Team" below, since staff/settings management is a company_admin
// concern. This is a UX convenience so staff never see a link that
// would 403 — the actual enforcement is the 'company_admin'
// middleware on those routes (see routes/web.php), not this file.
//
// Filtering for both happens in layouts/app.blade.php via
// acasFilterMenuForCompany() — this file stays pure data.
//
// IMPORTANT: only put routes here that every viewer of this menu is
// actually allowed to visit. The 'company' menu is shared by staff,
// company admins, AND a super admin who's browsing into a company —
// a route restricted to super admins (like super-admin.dashboard)
// does not belong in it, since a regular staff member clicking it
// would hit a 403. See layouts/app.blade.php for how a super-admin-
// only "back to overview" link gets added conditionally instead.

return [

    'super_admin' => [
        ['label' => 'Dashboard', 'icon' => 'bi-speedometer2', 'route' => 'super-admin.dashboard'],
        ['label' => 'Companies', 'icon' => 'bi-buildings', 'route' => 'super-admin.companies.index'],
        [
            'label' => 'Team',
            'icon' => 'bi-people',
            'route' => null,
            'children' => [
                ['label' => 'Super admins', 'route' => 'super-admin.super-admins.index'],
                ['label' => 'Company admins', 'route' => 'super-admin.company-admins.index'],
            ],
        ],
        ['label' => 'Reports', 'icon' => 'bi-graph-up', 'route' => 'super-admin.reports.index'],
    ],

    'company' => [
        ['label' => 'Dashboard', 'icon' => 'bi-speedometer2', 'route' => 'company.dashboard'],
        ['label' => 'Contacts', 'icon' => 'bi-people', 'route' => 'company.contacts.index'],
        [
            'label' => 'Sales',
            'icon' => 'bi-cash-stack',
            'route' => null,
            'children' => [
                ['label' => 'Pipelines', 'route' => 'company.pipelines.index', 'types' => \App\Models\Company::PIPELINE_ENABLED_TYPES],
                ['label' => 'Deals', 'route' => 'company.deals.index', 'types' => \App\Models\Company::PIPELINE_ENABLED_TYPES],
                [
                    'label' => 'Orders',
                    'route' => null,
                    'children' => [
                        ['label' => 'All orders', 'route' => 'company.orders.index', 'excludeTypes' => ['automotive', 'hotel']],
                        ['label' => 'Payments',   'route' => 'company.payments.index', 'excludeTypes' => ['automotive', 'hotel']],
                        ['label' => 'Receipts',   'route' => 'company.receipts.index', 'excludeTypes' => ['automotive', 'hotel']],
                    ],
                ],
            ],
        ],
        [
            'label' => 'Products',
            'icon' => 'bi-box-seam',
            'route' => null,
            'excludeTypes' => ['automotive', 'hotel'],
            'children' => [
                ['label' => 'All products', 'route' => 'company.products.index'],
                ['label' => 'Categories', 'route' => 'company.product-categories.index'],
            ],
        ],
        [
            'label' => 'Operations',
            'icon' => 'bi-diagram-3',
            'route' => null,
            'children' => [
                ['label' => 'Properties', 'route' => 'company.properties.index', 'types' => ['properties']],
                ['label' => 'Leases', 'route' => 'company.leases.index', 'types' => ['properties']],
                // ['label' => 'Vehicles & bookings', 'route' => 'company.vehicles.index', 'types' => ['automotive']],
                ['label' => 'Stock', 'route' => 'company.stock-lots.index', 'types' => \App\Models\Company::STOCK_TRACKED_TYPES],
                ['label' => 'Vehicle listings', 'route' => 'company.vehicle-listings.index', 'types' => ['automotive']],
                ['label' => 'Sales & rentals', 'route' => 'company.vehicle-transactions.index', 'types' => ['automotive']],

                ['label' => 'Payments', 'route' => 'company.payments.index', 'types' => ['automotive', 'hotel']],
                ['label' => 'Receipts', 'route' => 'company.receipts.index', 'types' => ['automotive', 'hotel']],

                ['label' => 'Pharmacy stock', 'route' => 'company.pharmacy-batches.index', 'types' => ['pharmacy']],
                ['label' => 'Crop cycles', 'route' => 'company.crop-cycles.index', 'types' => ['farms', 'agric_services']],
                ['label' => 'Livestock', 'route' => 'company.livestock-batches.index', 'types' => ['farms', 'agric_services']],
                ['label' => 'Solar projects', 'route' => 'company.solar-projects.index', 'types' => ['energy']],
                ['label' => 'Engagements', 'route' => 'company.engagements.index', 'types' => ['agric_services', 'farms']],
                ['label' => 'Rooms',        'route' => 'company.hotel-rooms.index',  'types' => ['hotel']],
                ['label' => 'Reservations', 'route' => 'company.reservations.index', 'types' => ['hotel']],
            ],
        ],
        [
            'label' => 'Team',
            'icon' => 'bi-person-badge',
            'route' => null,
            'adminOnly' => true,
            'children' => [
                ['label' => 'Staff', 'route' => 'company.staff.index'],
                ['label' => 'Company settings', 'route' => 'company.settings.edit'],
            ],
        ],
    ],

];
